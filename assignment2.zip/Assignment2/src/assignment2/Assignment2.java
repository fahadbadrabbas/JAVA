/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment2;

import java.util.Scanner;

public class Assignment2 {

    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter your name: ");
        String name = input.nextLine();
        System.out.println("Enter the total amount to be paid in USD: ");
        double dollars = input.nextInt();
        System.out.println("Enter your age to check if you are qualified for a discount: ");
        double age = input.nextDouble();
        if(age>=60){
            System.out.println("Congratulations. You’re eligible for a 10$ discount. Your total amount now is "+ (dollars - 10));
            
        }
        else if(age<18){
            System.out.println("Congratulations. You’re eligible for a 20$ discount. Your total amount now is "+(dollars - 20));
        }
        else 
            System.out.println("Congratulations. You’re eligible for a 5$ discount. Your total amount now is "+(dollars - 5));
                  
                    
    
                        

    }
    
}
