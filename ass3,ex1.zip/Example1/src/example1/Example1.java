/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package example1;
import java.util.Scanner;


public class Example1 {

    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
        
        int number = 0;
        int reverse =0;
        int sum =0;
        int r=0;
        System.out.println("Enter an integer: ");
        number = input.nextInt();
        do
        {
            r = number%10;
            reverse= reverse*10+r;
            sum = sum+r;
            number = number/10;
        }
        while(number>0);
        System.out.println("The reverse of the integers is: "+reverse);
        System.out.println("The sum of the integers is: "+sum);
    }
    
}
